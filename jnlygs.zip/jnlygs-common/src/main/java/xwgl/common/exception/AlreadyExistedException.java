package xwgl.common.exception;

public class AlreadyExistedException extends BusinessException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1916332272719865475L;

	public AlreadyExistedException(String defaultMessage) {
		super(defaultMessage);
	}

}
