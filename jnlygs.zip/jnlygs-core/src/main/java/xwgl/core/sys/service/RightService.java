package xwgl.core.sys.service;

import org.springframework.stereotype.Service;

import xwgl.common.service.SimpleCurdService;
import xwgl.core.sys.entity.Right;
@Service
public class RightService  extends SimpleCurdService<Right, Long> {
	
	
}
