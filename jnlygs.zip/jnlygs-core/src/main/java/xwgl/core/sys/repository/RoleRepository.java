package xwgl.core.sys.repository;
import xwgl.common.repository.SimpleCurdRepository;
import xwgl.core.sys.entity.Role;
public interface RoleRepository   extends SimpleCurdRepository<Role ,Long>{
}
