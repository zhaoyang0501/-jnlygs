
package xwgl.core.project.service;

import org.springframework.stereotype.Service;

import xwgl.common.service.SimpleCurdService;
import xwgl.core.project.entity.MsgBoard;
/***
 * 
 * @author qq:263608237
 *
 */
@Service
public class MsgBoardService extends SimpleCurdService< MsgBoard, Long>{
    
}