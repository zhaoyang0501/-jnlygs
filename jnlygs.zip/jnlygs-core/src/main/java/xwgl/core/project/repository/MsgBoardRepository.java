package xwgl.core.project.repository;

import xwgl.common.repository.SimpleCurdRepository;
import xwgl.core.project.entity.MsgBoard;

public interface MsgBoardRepository   extends SimpleCurdRepository<MsgBoard ,Long>{
}
