package xwgl.core.project.repository;
import xwgl.common.repository.SimpleCurdRepository;
import xwgl.core.project.entity.Hotel;

public interface HotelRepository extends SimpleCurdRepository<Hotel ,Long>{
}

