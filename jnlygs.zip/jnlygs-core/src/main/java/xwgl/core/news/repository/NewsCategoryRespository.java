package xwgl.core.news.repository;

import xwgl.common.repository.SimpleCurdRepository;
import xwgl.core.news.entity.NewsCategory;

public interface NewsCategoryRespository  extends SimpleCurdRepository<NewsCategory ,Long>{
	
}
