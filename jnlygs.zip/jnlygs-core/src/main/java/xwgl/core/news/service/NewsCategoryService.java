package xwgl.core.news.service;

import org.springframework.stereotype.Service;

import xwgl.common.service.SimpleCurdService;
import xwgl.core.news.entity.NewsCategory;
@Service
public class NewsCategoryService extends SimpleCurdService<NewsCategory, Long> {
	
	
	
}
